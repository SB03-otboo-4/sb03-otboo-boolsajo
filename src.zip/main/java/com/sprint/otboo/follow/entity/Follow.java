package com.sprint.otboo.follow.entity;

public class Follow {

}
