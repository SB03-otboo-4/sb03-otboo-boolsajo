package com.sprint.otboo.follow.service;

public interface FollowService {

}
