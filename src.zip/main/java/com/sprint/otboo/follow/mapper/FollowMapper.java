package com.sprint.otboo.follow.mapper;

public class FollowMapper {

}
