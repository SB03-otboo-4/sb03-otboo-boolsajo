package com.sprint.otboo.follow.repository;

public interface FollowRepository {

}
