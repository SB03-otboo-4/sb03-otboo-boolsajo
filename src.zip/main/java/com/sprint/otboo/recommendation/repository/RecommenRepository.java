package com.sprint.otboo.recommendation.repository;

public interface RecommenRepository {

}
