package com.sprint.otboo.recommendation.service;

public interface RecommendationService {

}
