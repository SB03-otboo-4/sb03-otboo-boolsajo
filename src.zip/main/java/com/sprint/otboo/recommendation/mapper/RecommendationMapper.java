package com.sprint.otboo.recommendation.mapper;

public interface RecommendationMapper {

}
