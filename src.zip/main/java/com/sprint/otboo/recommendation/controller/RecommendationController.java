package com.sprint.otboo.recommendation.controller;

public class RecommendationController {

}
