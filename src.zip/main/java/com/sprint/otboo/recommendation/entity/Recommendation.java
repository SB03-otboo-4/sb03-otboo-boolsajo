package com.sprint.otboo.recommendation.entity;

public class Recommendation {

}
