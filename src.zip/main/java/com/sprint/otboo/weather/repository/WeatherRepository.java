package com.sprint.otboo.weather.repository;

public interface WeatherRepository {

}
