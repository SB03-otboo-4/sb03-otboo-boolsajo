package com.sprint.otboo.weather.entity;

public class Weather {

}
