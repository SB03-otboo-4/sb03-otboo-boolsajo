package com.sprint.otboo.weather.entity;

public enum WindStrength {
    WEAK,
    MODERATE,
    STRONG
}