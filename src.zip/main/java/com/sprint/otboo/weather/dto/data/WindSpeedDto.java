package com.sprint.otboo.weather.dto.data;

public record WindSpeedDto(
    double speed,
    String asWord
) {

}
