package com.sprint.otboo.weather.dto.data;

public record HumidityDto(
    double current,
    double comparedToDayBefore
) {

}
