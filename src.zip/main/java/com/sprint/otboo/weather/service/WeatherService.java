package com.sprint.otboo.weather.service;

public interface WeatherService {

}
