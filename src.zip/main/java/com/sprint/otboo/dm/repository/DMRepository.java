package com.sprint.otboo.dm.repository;

public interface DMRepository {

}
