package com.sprint.otboo.dm.entity;

public class DM {

}
