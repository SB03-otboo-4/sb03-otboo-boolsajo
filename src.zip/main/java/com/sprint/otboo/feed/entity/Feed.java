package com.sprint.otboo.feed.entity;

public class Feed {

}
