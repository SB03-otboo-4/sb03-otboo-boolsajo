package com.sprint.otboo.feed.repository;

public class FeedRepository {

}
