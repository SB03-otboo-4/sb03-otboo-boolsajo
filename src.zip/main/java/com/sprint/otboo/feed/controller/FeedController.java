package com.sprint.otboo.feed.controller;

public class FeedController {

}
