package com.sprint.otboo.user.controller;

public class UserController {

}
