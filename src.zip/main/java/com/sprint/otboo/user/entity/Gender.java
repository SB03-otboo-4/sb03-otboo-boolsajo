package com.sprint.otboo.user.entity;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
