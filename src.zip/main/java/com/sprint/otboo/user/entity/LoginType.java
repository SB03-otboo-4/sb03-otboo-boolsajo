package com.sprint.otboo.user.entity;

public enum LoginType {
    GENERAL,
    GOOGLE,
    KAKAO
}
