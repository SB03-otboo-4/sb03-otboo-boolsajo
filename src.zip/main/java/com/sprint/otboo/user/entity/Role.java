package com.sprint.otboo.user.entity;

public enum Role {
    USER,
    ADMIN
}
