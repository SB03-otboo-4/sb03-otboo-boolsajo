package com.sprint.otboo.user.repository;

public class UserRepository {

}
