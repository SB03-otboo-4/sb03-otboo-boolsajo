package com.sprint.otboo.notification.repository;

public class NotificationRepository {

}
