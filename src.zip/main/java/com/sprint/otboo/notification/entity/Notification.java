package com.sprint.otboo.notification.entity;

public class Notification {

}
