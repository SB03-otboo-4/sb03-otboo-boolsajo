package com.sprint.otboo.notification.entity;

public enum NotificationLevel {
    INFO,
    WARNING,
    ERROR
}
