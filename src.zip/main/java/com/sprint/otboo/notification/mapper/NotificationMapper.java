package com.sprint.otboo.notification.mapper;

public class NotificationMapper {

}
