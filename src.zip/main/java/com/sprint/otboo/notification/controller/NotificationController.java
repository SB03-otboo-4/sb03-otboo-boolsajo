package com.sprint.otboo.notification.controller;

public class NotificationController {

}
