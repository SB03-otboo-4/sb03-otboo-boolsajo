package com.sprint.otboo.clothing.repository;

public interface ClothesRepository {

}
