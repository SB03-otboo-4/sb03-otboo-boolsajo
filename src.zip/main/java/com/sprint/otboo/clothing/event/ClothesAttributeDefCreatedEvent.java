package com.sprint.otboo.clothing.event;


public record ClothesAttributeDefCreatedEvent(
    String attributeName
) {
}

