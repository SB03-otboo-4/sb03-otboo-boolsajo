package com.sprint.otboo.clothing.entity;

public class ClothesAttributeDef {

}
