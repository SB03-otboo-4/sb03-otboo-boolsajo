package com.sprint.otboo.clothing.entity;

public class ClothesAttribute {

}
