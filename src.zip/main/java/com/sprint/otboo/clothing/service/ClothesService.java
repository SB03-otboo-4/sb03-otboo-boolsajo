package com.sprint.otboo.clothing.service;

public interface ClothesService {

}
