package com.sprint.otboo.clothing.mapper;

public interface ClothesMapper {

}
