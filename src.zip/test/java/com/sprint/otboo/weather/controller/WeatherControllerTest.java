package com.sprint.otboo.weather.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.sprint.otboo.common.exception.GlobalExceptionHandler;
import com.sprint.otboo.weather.dto.response.WeatherLocationResponse;
import com.sprint.otboo.weather.service.WeatherLocationQueryService;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(WeatherController.class)
@AutoConfigureMockMvc(addFilters = false)
@Import(GlobalExceptionHandler.class)
@DisplayName("WeatherController 테스트")
class WeatherControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockitoBean
    private WeatherLocationQueryService service;

    @Test
    void 정상_요청은_200과_올바른_본문을_반환해야_한다() throws Exception {
        WeatherLocationResponse response =
            new WeatherLocationResponse(37.5665,126.9780,60,127,
                List.of("서울특별시","중구","태평로1가"));
        given(service.getWeatherLocation(anyDouble(), anyDouble()))
            .willReturn(response);

        mvc.perform(get("/api/weathers/location")
                .param("longitude","126.9780")
                .param("latitude","37.5665"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.x", is(60)))
            .andExpect(jsonPath("$.y", is(127)))
            .andExpect(jsonPath("$.locationNames", hasSize(3)));
    }

    @Test
    void 파라미터가_누락되면_400을_반환해야_한다() throws Exception {
        mvc.perform(get("/api/weathers/location")
                .param("longitude","126.9780"))
            .andExpect(status().isBadRequest());
    }
}
